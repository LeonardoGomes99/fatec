// Replace with your request types
export const GET_DATA_REQUEST = 'GET_DATA_REQUEST';
export const GET_DATA_RECEIVE = 'GET_DATA_RECEIVE';
