import en from './en';
import ar from './ar';

const messages = {
  ...ar, 
  ...en
}

export default messages;