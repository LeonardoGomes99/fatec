/*** VARIAVEIS GLOBAIS ***/


var bleep = new Audio();
bleep.src = "./Assets/conf.wav";
var distanceBetween;
var LocationStatus;
var myInterval;
var dNow = new Date();
var hora = dNow.getHours() + ':' + dNow.getMinutes();
var thisOne = "";
var data = new Date();

/*** VARIAVEIS GLOBAIS ***/


/*** DICIONÁRIO DE PALAVRAS ***/

var obj = ({        
        "chamado":{
            "oi" : ["Ola, vou te ajudar!", "Olá, do que precisa?"],
            "como vai" : ["Vou bem, obrigada!", "To cansada, dificil ser assistente virtual.", "Tudo sossegado na terra de zeros e uns!"],
            "você está" : ["Estou bem.", "Estou ótima.", "Estou Topper."],

            "Oi" : ["Ola, vou te ajudar!", "Olá, do que precisa?"],
            "Como vai" : ["Vou bem, obrigada!", "To cansada, dificil ser assistente virtual.", "Tudo sossegado na terra de zeros e uns!"],            
            "Você está" : ["Estou bem.", "Estou ótima.", "Estou Topper."],
        },
        "quarto" : {
            "Acend": ["Acendendo a luz do quarto.GPIO16ON", "Luz do quarto acesa.GPIO16ON"],
            "Apag": ["Apagando luz do quarto.GPIO16OFF", "Luz do quarto apagada.GPIO16OFF"],
            "acend": ["Acendendo a luz do quarto.GPIO16ON", "Luz do quarto acesa.GPIO16ON"],
            "apag": ["Apagando luz do quarto.GPIO16OFF", "Luz do quarto apagada.GPIO16OFF"],
        },
        "sala":{
            "Acend": ["Acendendo luz da sala.GPIO5ON", "Luz da sala acesa.GPIO5ON"],
            "Apag": ["Apagando luz da sala.GPIO5OFF", "Luz da sala apagada.GPIO5OFF"],
            "acend": ["Acendendo luz da sala.GPIO5ON", "Luz da sala acesa.GPIO5ON"],
            "apag": ["Apagando luz da sala.GPIO5OFF", "Luz da sala apagada.GPIO5OFF"]

        }
 
    });

/*** DICIONÁRIO DE PALAVRAS ***/


/*** CRIAR MENSAGEM ***/

function UserMessageSend(message){
    imageUser = "./Assets/user.png";
  $('#myContainer').append('<div class="msg right-msg"> <div class="msg-img" style="background-image: url('+imageUser+')" ></div> <div class="msg-bubble"> <div class="msg-info"> <div class="msg-info-name">Usuario</div> <div class="msg-info-time">'+hora+'</div> </div> <div class="msg-text">'+message+'</div> </div> </div>');
}
function BotMessageSend(message){
    imageBot = "./Assets/bot.png";
  $('#myContainer').append('<div class="msg left-msg"> <div class="msg-img" style="background-image: url('+imageBot+')" ></div> <div class="msg-bubble"> <div class="msg-info"> <div class="msg-info-name">ELIRIA</div> <div class="msg-info-time">'+hora+'</div> </div> <div class="msg-text">'+message+'</div> </div> </div>');
}

/*** CRIAR MENSAGEM ***/


/*** ENVIAR MENSAGEM ***/
$("#SendMessage").click(function(){  
    var user = $('#UserMessage').val();
    if(user !=""){  
      var message = user.charAt(0).toUpperCase() + user.slice(1);    
      $('#UserMessage').val("");

      if(message.includes("quarto") && message.includes("?") || message.includes("quarto")){
          UserMessageSend(message);
          Bedroom(message);
      //luz da sala
      }else if (message.includes("sala") && message.includes("?") || message.includes("sala")){
          UserMessageSend(message);
          Room(message);
      }else{
          UserMessageSend(message)
          Call(message);
      }
    }else{
      alert(" Campo de mensagens vázio");
    }
});

/*** ENVIAR MENSAGEM ***/



/*** ENVIAR COMANDO DE VOZ ***/

window.addEventListener('DOMContentLoaded', function() {
    var speakBtn = document.querySelector('#speakBtn');
   
    // testa se o navegador suporta o reconhecimento de voz
    if (window.SpeechRecognition || window.webkitSpeechRecognition) {
        
      
        // captura a voz
        var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;

        var recognition = new SpeechRecognition();

        // inicia reconhecimento
        speakBtn.addEventListener('click', function(e) {
            recognition.start();
            $("#speakBtn").css('background-color', '#9d5df1');
        }, false);

        // resultado do reconhecimento
        recognition.addEventListener('result', function(e) {
            console.log(e);
            $("#speakBtn").css('background-color', '#EEEEEE');
            var convex = e.results[0][0].transcript;

            var convex = convex.replace(/Elyria|elyria|Liria|Lilian|Ele|ele|Emily|Líria|Eniria|Lili/, "Eliria");

            var result = convex.charAt(0).toUpperCase() + convex.slice(1);

            UserMessageSend(result);                        
            message = result;            

            if(message.includes("quarto") && message.includes("?") || message.includes("quarto")){
                
                Bedroom(message);
            //luz da sala
            }else if (message.includes("sala") && message.includes("?") || message.includes("sala")){
                
                Room(message);
            }else{
               
                Call(message);
            }
            
        }, false);
    } else {
        alert('Esta plataforma/Navegador não suporta a funcionalidade de comando de voz e geolocalização ainda!');
    }
}, false);

/*** ENVIAR COMANDO DE VOZ ***/


/*** FUNÇÕES PARA IDENTIFICAR PERGUNTAS E DAR RESPOSTAS E MANDAR COMANDOS PARA ESP ***/

function Bedroom(message){
    let whichOne = (Object.keys(obj['quarto']));
    for(var words in whichOne){            
        var isThisOne = (whichOne[words]);
        if(message.includes(isThisOne)){
            thisOne = isThisOne;               
        }
        
    }
    if(thisOne !=""){
        var randomItem = (obj['quarto'][thisOne])[Math.floor(Math.random()*(obj['quarto'][thisOne]).length)];
        console.log(randomItem);
        var res = randomItem.split(".");            
        BotMessageSend(res[0]);
        sendToEspThroughAjax(res[1],"relaya");

    }else{
      BotMessageSend("Não entendi, pode repetir?");  
      console.log("Deu Ruim");
    }
}

function Room(message){
    let whichOne = (Object.keys(obj['sala']));
    for(var words in whichOne){            
        var isThisOne = (whichOne[words]);
        if(message.includes(isThisOne)){
            thisOne = isThisOne;
        }
        
    }
    if(thisOne !=""){
        var randomItem = (obj['sala'][thisOne])[Math.floor(Math.random()*(obj['sala'][thisOne]).length)];
        console.log(randomItem);
        var res = randomItem.split(".");
        BotMessageSend(res[0]);
        sendToEspThroughAjax(res[1],"relayb");
    }
}


function Call(message){
    let whichOne = (Object.keys(obj['chamado']));
    for(var words in whichOne){
        var isThisOne = (whichOne[words]);
        if(message.includes(isThisOne)){
            thisOne = isThisOne;
        }
        
    }
    if(thisOne !=""){
        var randomItem = (obj['chamado'][thisOne])[Math.floor(Math.random()*(obj['chamado'][thisOne]).length)];
        console.log(randomItem);
        var res = randomItem.split(".");
        BotMessageSend(res[0]);        
    }
}

/*** FUNÇÕES PARA IDENTIFICAR PERGUNTAS E DAR RESPOSTAS E MANDAR COMANDOS PARA ESP ***/


/*** DISTANCIA ENTRE O ESP ***/

    function v1(){
    myInterval = setInterval(function()
    {
      getLocation();
    }, 3000);
    }


  function v2(){
  clearInterval(myInterval);
  }



function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    alert("Este Navegador/Dispositivo não suporta a funcionalidade de localização");
  }
}

function showPosition(position) {
    //getDistanceFromLatLonInKm(-22.557215, -44.961166,position.coords.latitude,position.coords.longitude);
    //getDistanceFromLatLonInKm(position.coords.latitude,position.coords.longitude , position.coords.latitude,position.coords.longitude);
    //getDistanceFromLatLonInKm(-22.557215, -44.961166,-22.556976, -44.960891); //<-Da praça até a casa. 37 metros <casa / praça> 37 m = 0.037
    //getDistanceFromLatLonInKm(-22.557215, -44.961166,-22.557137, -44.961077); //<-Da praça até a casa. 13 metros <casa / perto casa> 13 m = 0.013


    getDistanceFromLatLonInKm(-22.557215, -44.961166,position.coords.latitude,position.coords.longitude);
    console.log(position.coords.latitude,position.coords.longitude);

}

function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2-lat1);  // deg2rad below
  var dLon = deg2rad(lon2-lon1);
  var a =
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ;
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  var d = R * c; // Distance in km
  console.log(d);
  distanceBetween = d.toFixed(3);


  //BotMessageSend("Distancia entre os 2 objetos: "+distanceBetween);
  console.log(parseFloat(distanceBetween));

  if(parseFloat(distanceBetween).toFixed(3) <= 0.025 && parseFloat(distanceBetween).toFixed(3) > 0.020){
    sendToEspThroughAjax(["GPIO16ON","GPIO5OFF","GPIO4OFF",distanceBetween]);
  }else if(parseFloat(distanceBetween).toFixed(3) <= 0.020 && parseFloat(distanceBetween).toFixed(3) > 0.015){
    sendToEspThroughAjax(["GPIO16ON","GPIO5ON","GPIO4OFF",distanceBetween]);
  }else if(parseFloat(distanceBetween).toFixed(3) <= 0.015){
    sendToEspThroughAjax(["GPIO16ON","GPIO5ON","GPIO4ON",distanceBetween]);
  }else{
    sendToEspThroughAjax(["GPIO16OFF","GPIO5OFF","GPIO4OFF",distanceBetween]);
  }


}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}

$("#cmn-toggle-4").on("change", function (event) {
    if ($(this).is(":checked")) {
        v1();
    } else {
		v2();
    }
});

/*** DISTANCIA ENTRE O ESP ***/

/*** ENVIAR AJAX ***/

function sendToEspThroughAjax(data,tipo){
    data = [data];
    $.ajax({        
            type: "POST",
            //url: "http://localhost/Eliria_Housecarl_Web/7815ed053b0e060537c6490aaed006dd/salvar.php",
            url: "https://eliria-housecarl-web.herokuapp.com/7815ed053b0e060537c6490aaed006dd/salvar.php",
            data: {
                data : data,
                tipo
            },
            success: function(data) {
            }
        });
  }

/*** ENVIAR AJAX ***/
