<?php

if(count($_POST) > 1 ){

    if( ($_POST['tipo']) == "relaya" ){
        $data = ($_POST["data"][0]);
        $json_data = json_encode($data);
        file_put_contents('relaya.json', $json_data);

    }else if( ($_POST['tipo']) == "relayb" ){
        $data = ($_POST["data"][0]);
        $json_data = json_encode($data);
        file_put_contents('relayb.json', $json_data);
        
    }

}else{

    $data = ($_POST["data"][0][0]);
    $json_data = json_encode($data);
    file_put_contents('relaya.json', $json_data);


    $data = ($_POST["data"][0][1]);
    $json_data = json_encode($data);
    file_put_contents('relayb.json', $json_data);
        

    $data = ($_POST["data"][0][2]);
    $json_data = json_encode($data);
    file_put_contents('servo.json', $json_data);

    $data = $_POST["data"][0][3];
    $json_data = json_encode($data);
    file_put_contents('location.json', $json_data);

}








