
<?php

$str = file_get_contents('servo.json');
$json = json_decode($str, true);
echo $json;







