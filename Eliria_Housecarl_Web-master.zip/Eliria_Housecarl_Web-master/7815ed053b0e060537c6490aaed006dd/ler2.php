
<?php

$str = file_get_contents('relayb.json');
$json = json_decode($str, true);
echo $json;