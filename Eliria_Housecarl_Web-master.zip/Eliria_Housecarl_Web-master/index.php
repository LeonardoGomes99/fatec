<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <meta name="description" content="Template Eliria Housecarl para acessos web">
    <meta name="author" content="Inovatik">


	<meta property="og:site_name" content="" />
	<meta property="og:site" content="" />
	<meta property="og:title" content=""/>
	<meta property="og:description" content="" />
	<meta property="og:image" content="" />
	<meta property="og:url" content="" />
	<meta property="og:type" content="article" />

    <title>Eliria Housecarl</title>

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,700i" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js" type="text/javascript"></script>

    <link href="./assets/css/bootstrap.css" rel="stylesheet">
    <link href="./assets/css/fontawesome-all.css" rel="stylesheet">
    <link href="./assets/css/swiper.css" rel="stylesheet">
	<link href="./assets/css/magnific-popup.css" rel="stylesheet">
	<link href="./assets/css/styles.css" rel="stylesheet">

    <link rel="icon" href="assets/images/bot2.png">
</head>
<body data-spy="scroll" data-target=".fixed-top">

	<div class="spinner-wrapper">
        <div class="spinner">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
        </div>
    </div>


    <nav class="navbar navbar-expand-md navbar-dark navbar-custom fixed-top">


        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="#features">FEATURES/DEMO</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="#details">DETALHES</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link page-scroll" href="#contact">INTEGRANTES</a>
                </li>
            </ul>
        </div>
    </nav>



    <header id="header" class="header">
        <div class="header-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text-container">
                            <h1>- ELIRIA HOUSECARL -<br><span id="js-rotating">ASSISTENTE, VIRTUAL, RESIDENCIAL</span></h1>
                            <p class="p-large">Bem vindo ao nosso protótipo de IOT é um prazer conhecê-lo!</p>

                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="image-container">
                            <img class="img-fluid" src="./assets/images/Eliria1img.png" alt="alternative">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>







    <div id="features" class="tabs">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>FEATURES</h2>
                    <div class="p-heading p-large">Eliria foi desenvolvida com a ideia de ser um protótipo de automação residencial de baixo custo</div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-heading p-large"><h4>CLIQUE NO CELULAR ABAIXO E FALE COM A ELIRIA <i class="fas fa-arrow-circle-down" "></i></h4></div>
                </div>
            </div>
            <div class="row">


                <div class="tab-content" id="lenoTabsContent">

                    <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
                        <div class="container">
                            <div class="row">

                                <div class="col-lg-4">
                                    <div class="card left-pane first">
                                        <div class="card-body">
                                            <div class="text-wrapper">
                                                <h4 class="card-title">POR VOZ</h4>
                                                <p>Ela possui reconhecimento de comandos por fala.</p>
                                            </div>
                                            <div class="card-icon">
                                              <i class="fas fa-microphone-alt"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card left-pane">
                                        <div class="card-body">
                                            <div class="text-wrapper">
                                                <h4 class="card-title">POR TEXTO</h4>
                                                <p>Ela entende comandos digitados no chat.</p>
                                            </div>
                                            <div class="card-icon">
                                                <i class="far fa-edit"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card left-pane">
                                        <div class="card-body">
                                            <div class="text-wrapper">
                                            <h4 class="card-title">MOBILE</href></h4>
                                                <p>Multiplataforma! A Eliria está disponível para usuários Android.</p>
                                                <a href='App-Download/Eliria_Housecarl.apk'><p><b>Baixe Aqui</b></p></a>
                                            </div>
                                            <div class="card-icon">
                                              <i class="fas fa-mobile-alt"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <img class="img-fluid" id="LiveDemo" src="./assets/images/screenshot-3-2.png" alt="alternative" style="cursor: pointer;">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab-3">
                        <div class="container">
                            <div class="row">

                                <div class="col-md-4">
                                    <img class="img-fluid" src="./assets/images/screenshot-3-2.png" alt="alternative">
                                </div>

                            </div>
                        </div>
                    </div>
                </div>                
            </div>
        </div>
    </div>

    


    <div id="details" class="basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <img class="img-fluid" src="./assets/images/DetalhesEliriaV2.png" alt="alternative">
                </div>
                <div class="col-lg-6">
                    <div class="text-container">
                        <h3>- DETALHES -</h3>
                        <p>Controle a sua casa por comandos de voz ou escrevendo no chat. Além disso ela possui o recurso geolocalização em que você define o que ela deve realizar de acordo com a distância que você se encontra do local. Em breve multiplataforma!</p>
                    </div>                    
                </div>
            </div>
        </div>
    </div>



    <div class="slider-1" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <div class="slider-container">
                        <div class="swiper-container card-slider">
                            <div class="swiper-wrapper">

                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="card-image" src="./assets/images/2.jpg" alt="alternative">
                                        <div class="card-body">
                                            <p class="testimonial-text">Lead Programmer</p>
                                            <p class="testimonial-author">Leonardo Gomes da Silva</p>

                                              <a href="https://github.com/LeonardoGomes99">
                                              <i class="fab fa-github"></i>
                                              </a>

                                              <a href="https://www.linkedin.com/in/leonardo-gomes-63a2b717b/">
                                                <i class="fab fa-linkedin"></i>
                                              </a>

                                        </div>
                                    </div>
                                </div>

                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="card-image" src="./assets/images/3.jpeg" alt="alternative">
                                        <div class="card-body">
                                            <p class="testimonial-text">Programmer</p>
                                            <p class="testimonial-author">Luisa Couto</p>

                                              <a href="https://github.com/luisaacouto">
                                              <i class="fab fa-github"></i>
                                              </a>

                                              <a href="https://www.linkedin.com/in/luisa-couto-41b68b16a/">
                                                <i class="fab fa-linkedin"></i>
                                              </a>

                                        </div>
                                    </div>
                                </div>


                                <div class="swiper-slide">
                                    <div class="card">
                                        <img class="card-image" src="./assets/images/1.jpeg" alt="alternative">
                                        <div class="card-body">
                                            <p class="testimonial-text">Documentação</p>
                                            <p class="testimonial-author">Vitoria Narciso</p>

                                                <a href="https://github.com/vitorianarciso">
                                                <i class="fab fa-github"></i>
                                                </a>

                                                <a href="https://www.linkedin.com/in/vit%C3%B3ria-cristina-narciso-64626a191/">
                                                  <i class="fab fa-linkedin"></i>
                                                </a>

                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>

                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>


    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="p-small">Copyright © Eliria Housecarl - Web Application/Mobile</p>
                </div>
            </div>
        </div>
    </div>

    <div class="modal" id="thisModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" style="color: black;">DEMO WEB</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            
        <div class="embed-responsive embed-responsive-4by3">
            <iframe class="embed-responsive-item" src="./Eliria-Chat/index.html" allowfullscreen></iframe>
        </div>

        </div>        
        </div>
    </div>
    </div>


      <script>
      $(document).ready(function(){
        $("#LiveDemo").click(function(){
          $('#thisModal').modal('show');
          });
      });
      </script>

    <script src="./assets/js/jquery.min.js"></script>
    <script src="./assets/js/popper.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <script src="./assets/js/jquery.easing.min.js"></script>
    <script src="./assets/js/swiper.min.js"></script>
    <script src="./assets/js/jquery.magnific-popup.js"></script>
    <script src="./assets/js/morphext.min.js"></script>
    <script src="./assets/js/validator.min.js"></script>
    <script src="./assets/js/scripts.js"></script>
</body>
</html>
