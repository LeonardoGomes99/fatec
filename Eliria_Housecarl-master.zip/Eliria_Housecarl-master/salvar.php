<?php
$data = $_POST["data"];

$arquivo = fopen("save.txt", "a");

file_put_contents("save.txt", "");
fwrite($arquivo, "$data");

fclose($arquivo);

