<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Eliria Housecarl</title>
    <link rel="icon" type="image/x-icon" href="assets/img/bot.png" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>

<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Eliria</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars ml-1"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav text-uppercase ml-auto">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#services">Sobre o Projeto</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#team">Equipe</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Masthead-->
    <header class="masthead">
        <br>
        <br>
        <br>
        <br>
        <div class="masthead-subheading">Bem vindo ao nosso Protótipo de IOT</div>
            <div class="masthead-heading text-uppercase">É um prazer conhece-lo</div>
            <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">O que precisa?</a>
        </div>
        <div class="chatbox">
            <div class="chatlogs" id="chatlogi">
            </div>

            <div class="chat-form">
                <textarea maxlength="23" id="texto"></textarea>

                <button class="button" onmousedown="bleep.play()" style="border: 0; background: transparent" onclick="textBtn()">
                    <img src="assets/img/send.png" width="30" height="25" alt="submit" />
                </button>

                <button class="button" onmousedown="bleep.play()" style="border: 0; background: transparent" id="speakBtn">
                    <img src="assets/img/mic.png" width="30" height="25" alt="submit" />
                </button>

                <button class="button" onmousedown="bleep.play()" style="border: 0; background: transparent" onclick="btnBlink()">
                    <img src="assets/img/lamp.png" width="30" height="25" alt="submit" />
                </button>
            </div>
        </div>
    </header>
    <!-- Services-->
    <section class="page-section" id="services">
        <div class="container">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">Sobre a Eliria</h2>
                <br>
                <br>
                <br>
                <br>
            </div>
            <div class="row text-center">
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fas fa-circle fa-stack-2x text-primary"></i>
                        <i class="fas fa-shopping-cart fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="my-3">E-Commerce</h4>
                    <p class="text-muted"> Estimativas do Gartner apontam que os gastos globais com Tecnologia da
                        Informação chegarão a cifra de US$ 3,76 trilhões em 2019, um aumento de 3,2% em relação a 2018.
                    </p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fas fa-circle fa-stack-2x text-primary"></i>
                        <i class="fas fa-laptop fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="my-3">Responsive Design</h4>
                    <p class="text-muted">Design Responsivo e limpo para todos os dispositivos</p>
                </div>
                <div class="col-md-4">
                    <span class="fa-stack fa-4x">
                        <i class="fas fa-circle fa-stack-2x text-primary"></i>
                        <i class="fas fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="my-3">Web Security</h4>
                    <p class="text-muted">"".</p>
                </div>
            </div>
        </div>
    </section>
    <!-- About-->
    <!-- Team-->
    <section class="page-section bg-light" id="team">
        <div class="container">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">Nossa Incrível Equipe</h2>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="team-member">
                        <img class="mx-auto rounded-circle" src="assets/img/team/1.jpeg" alt="" />
                        <h4>Vitória Narciso</h4>
                        <p class="text-muted">Designer</p>
                        <a class="btn btn-dark btn-social mx-2" href="https://www.linkedin.com/in/vitória-cristina-narciso-64626a191/"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="team-member">
                        <img class="mx-auto rounded-circle" src="assets/img/team/2.jpg" alt="" />
                        <h4>Leonardo Gomes</h4>
                        <p class="text-muted">Lead Programmer</p>
                        <a class="btn btn-dark btn-social mx-2" href="https://www.linkedin.com/in/leonardo-gomes-63a2b717b/"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="team-member">
                        <img class="mx-auto rounded-circle" src="assets/img/team/3.jpeg" alt="" />
                        <h4>Luísa Couto</h4>
                        <p class="text-muted">Programmer</p>
                        <a class="btn btn-dark btn-social mx-2" href="https://www.linkedin.com/in/luisa-couto-41b68b16a/"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 text-lg-left">Copyright © Eliria Housecarl 2020</div>
                <div class="col-lg-4 my-3 my-lg-0">
                    <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-dark btn-social mx-2" href="#!"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </footer>
    <!-- Bootstrap core JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.bundle.min.js"></script>
    <!-- Third party plugin JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <!-- Contact form JS-->
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>


<!--ESTILO-->

<style>
    body {
        width: auto;
        height: auto;
    }

    .chatbox {
        width: 100%;
        height: auto;
        background: #fff;
        padding: 25px;
        margin: 20px auto;
        box-shadow: 0 3px #ccc;
        border: 2px solid #eee;
        border-radius: 3px;
    }

    .chatlogs {
        padding: 10px;
        width: 100%;
        border: 1px solid rgba(0, 0, 0, 0.3);
        height: 530px;
        overflow-x: hidden;
        overflow-y: scroll;
    }

    .chatlogs::-webkit-scrollbar {
        width: 18px;
    }

    .chatlogs::-webkit-scrollbar-thumb {
        border-radius: 5px;
        background: rgba(0, 0, 0, .1);
    }

    .chat {
        display: flex;
        flex-flow: row wrap;
        align-items: flex-start;
        margin-bottom: 10px;
    }

    .chat .user-photo {
        width: 50px;
        height: 50px;
        background: #ccc;
        border-radius: 50%;
        overflow: hidden;
    }

    .chat .user-photo img {
        width: 100%;
    }

    .chat .chat-message {
        width: 80%;
        padding: 15px;
        margin: 1px 10px 0;
        border-radius: 10px;
        color: #fff;
        font-size: 20px;
    }

    .bot .chat-message {
        background: #1adda4;
    }

    .me .chat-message {
        background: #1ddced;
        order: -1;
    }

    .chat-form {
        margin-top: 5px;
        display: flex;
        align-items: flex-start;

    }

    .chat-form textarea {
        background: #fbfbfb;
        width: 100%;
        height: 51px;
        border: 2px solid #eee;
        border-radius: 3px;
        resize: none;
        padding: 10px;
        font-size: 18px;
        color: #333;
    }

    .chat-form textarea:focus {
        background: #fff;
    }

    .chatlogs textarea::-webkit-scrollbar {
        width: 10px;
    }

    .chatlogs textarea::-webkit-scrollbar-thumb {
        border-radius: 5px;
        background: rgba(0, 0, 0, .1);
    }

    .chat-form button {
        background: #1ddced;
        padding: 5px 15px;
        font-size: 27px;
        color: #fff;
        margin: 0 6px;
        border: 1px solid rgba(0, 0, 0, 0.3);
        border-radius: 3px;
        box-shadow: 0 3px 0 rgba(0, 0, 0, .1);
        cursor: pointer;
        -webkit-transition: background .2s ease;
        -moz-transition: background .2s ease;
        -o-transition: background .2s ease;
    }
</style>

<!--SOUND EFFECT-->

<script>
    var bleep = new Audio();
    bleep.src = "assets/sfx/conf.wav";
</script>


<!--COMANDO TEXTO-->

<script>
    var dNow = new Date();
    var data = dNow.getDate() + '/' + (dNow.getMonth() + 1) + '/' + dNow.getFullYear();
    var hora = dNow.getHours() + ':' + dNow.getMinutes();

    know = {
        "Oi": "Olá",
        "Que dia é hoje": data,
        "Que horas são": hora,
        "Como vai": "muito bem :)",
        "Ligar": "ligando",
        "Desligar": "desligando",
        "Ok": ":D"
    };


    function textBtn() {


        var esp = document.createElement('br');
        var formatz = document.getElementById("texto").value;
        var user = formatz.charAt(0).toUpperCase() + formatz.slice(1);
        var imguser = document.createElement('img');
        imguser.src = 'assets/img/user.png';

        const element = document.createElement('div');
        element.classList.add('chat', 'me');

        imguser.style.width = "60px";
        imguser.style.height = "60px";
        imguser.style.background = "#ccc";
        imguser.style.borderRadius = "50%";
        imguser.style.overflow = 'hidden';
        imguser.style.float = 'right';


        element.setAttribute("src", "assets/img/user.png");
        element.setAttribute("width", "304");
        element.setAttribute("height", "228");
        element.setAttribute("alt", "The Pulpit Rock");

        element.style.width = "80%";
        element.style.padding = "15px";
        element.style.margin = "5px 10px 0";
        element.style.borderRadius = "10px";
        element.style.color = "#fff";
        element.style.size = "20px";
        element.style.background = "#1ddced";




        const elemText = document.createTextNode(user);

        element.appendChild(elemText);

        document.getElementById("chatlogi").appendChild(imguser);
        document.getElementById("chatlogi").appendChild(element);
        document.getElementById("chatlogi").appendChild(esp);
        console.log(element);

        const elemento = document.createElement('div');
        elemento.classList.add('chat', 'bot');
        console.log(elemento);

        if (user in know) {

            var espaco = document.createElement('br');
            var imgbot = document.createElement('img');
            imgbot.src = 'assets/img/bot.png';

            const elementoBot = document.createElement('div');
            elementoBot.classList.add('chat', 'botz');

            imgbot.style.width = "60px";
            imgbot.style.height = "60px";
            imgbot.style.background = "#ccc";
            imgbot.style.borderRadius = "50%";
            imgbot.style.overflow = 'hidden';
            imgbot.style.float = 'left';
            imgbot.style.margin = "10px";

            elementoBot.style.width = "80%";
            elementoBot.style.padding = "15px";
            elementoBot.style.margin = "5px 15px 0";
            elementoBot.style.borderRadius = "10px";
            elementoBot.style.color = "#fff";
            elementoBot.style.size = "20px";
            elementoBot.style.background = "#1adda4";


            const elemTextBot = document.createTextNode(know[user]);

            elementoBot.appendChild(elemTextBot);

            var espCommand = (know[user]);

            if (espCommand == "Ligando") {
                var data = "ligar";
                $.ajax({
                    type: "POST",
                    url: "salvar.php",
                    data: {
                        data
                    },
                    success: function(data) {

                    }
                })

            } else if (espCommand == "Desligando") {
                var data = "desligar";
                $.ajax({
                    type: "POST",
                    url: "salvar.php",
                    data: {
                        data
                    },
                    success: function(data) {

                    }
                })
            }

            document.getElementById("chatlogi").appendChild(imgbot);
            document.getElementById("chatlogi").appendChild(elementoBot);
            document.getElementById("chatlogi").appendChild(espaco);
            document.getElementById("texto").value = "";



        } else {
            var espaco = document.createElement('br');
            var imgbot = document.createElement('img');
            imgbot.src = 'assets/img/bot.png';

            const elementoBot = document.createElement('div');
            elementoBot.classList.add('chat', 'bot');

            imgbot.style.width = "60px";
            imgbot.style.height = "60px";
            imgbot.style.background = "#ccc";
            imgbot.style.borderRadius = "50%";
            imgbot.style.overflow = 'hidden';
            imgbot.style.float = 'left';
            imgbot.style.margin = "10px";

            elementoBot.style.width = "80%";
            elementoBot.style.padding = "15px";
            elementoBot.style.margin = "5px 15px 0";
            elementoBot.style.borderRadius = "10px";
            elementoBot.style.color = "#fff";
            elementoBot.style.size = "20px";
            elementoBot.style.background = "#1adda4";


            const elemTextBot = document.createTextNode("Não Entendi :(");

            elementoBot.appendChild(elemTextBot);


            document.getElementById("chatlogi").appendChild(imgbot);
            document.getElementById("chatlogi").appendChild(elementoBot);
            document.getElementById("chatlogi").appendChild(espaco);
            document.getElementById("texto").value = "";
        }
    }
</script>


<!--COMANDO VOZ-->

<script>
    var dNow = new Date();
    var data = dNow.getDate() + '/' + (dNow.getMonth() + 1) + '/' + dNow.getFullYear();
    var hora = dNow.getHours() + ':' + dNow.getMinutes();

    know = {
        "Oi": "Olá",
        "Que dia é hoje": data,
        "Que horas são": hora,
        "Como vai": "muito bem :)",
        "Ligar": "Ligando",
        "Desligar": "Desligando",
        "Ok": ":D"
    };
    window.addEventListener('DOMContentLoaded', function() {
        var speakBtn = document.querySelector('#speakBtn');

        // testa se o navegador suporta o reconhecimento de voz
        if (window.SpeechRecognition || window.webkitSpeechRecognition) {

            // captura a voz
            var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;

            var recognition = new SpeechRecognition();

            // inicia reconhecimento
            speakBtn.addEventListener('click', function(e) {
                recognition.start();
            }, false);

            // resultado do reconhecimento
            recognition.addEventListener('result', function(e) {
                console.log(e);
                var convex = e.results[0][0].transcript;
                var result = convex.charAt(0).toUpperCase() + convex.slice(1);
                console.log(result);

                if (result in know) {



                    //USER
                    var esp = document.createElement('br');
                    var user = result;
                    var imguser = document.createElement('img');
                    imguser.src = 'assets/img/user.png';

                    const element = document.createElement('div');
                    element.classList.add('chat', 'me');

                    imguser.style.width = "60px";
                    imguser.style.height = "60px";
                    imguser.style.background = "#ccc";
                    imguser.style.borderRadius = "50%";
                    imguser.style.overflow = 'hidden';
                    imguser.style.float = 'right';


                    element.setAttribute("src", "assets/img/user.png");
                    element.setAttribute("width", "304");
                    element.setAttribute("height", "228");
                    element.setAttribute("alt", "The Pulpit Rock");

                    element.style.width = "80%";
                    element.style.padding = "15px";
                    element.style.margin = "5px 10px 0";
                    element.style.borderRadius = "10px";
                    element.style.color = "#fff";
                    element.style.size = "20px";
                    element.style.background = "#1ddced";




                    const elemText = document.createTextNode(user);

                    element.appendChild(elemText);

                    document.getElementById("chatlogi").appendChild(imguser);
                    document.getElementById("chatlogi").appendChild(element);
                    document.getElementById("chatlogi").appendChild(esp);
                    console.log(element);

                    const elemento = document.createElement('div');
                    elemento.classList.add('chat', 'bot');
                    console.log(elemento);


                    //ELIRIA					
                    var espaco = document.createElement('br');
                    var imgbot = document.createElement('img');
                    imgbot.src = 'assets/img/bot.png';

                    const elementoBot = document.createElement('div');
                    elementoBot.classList.add('chat', 'botz');

                    imgbot.style.width = "60px";
                    imgbot.style.height = "60px";
                    imgbot.style.background = "#ccc";
                    imgbot.style.borderRadius = "50%";
                    imgbot.style.overflow = 'hidden';
                    imgbot.style.float = 'left';
                    imgbot.style.margin = "10px";

                    elementoBot.style.width = "80%";
                    elementoBot.style.padding = "15px";
                    elementoBot.style.margin = "5px 15px 0";
                    elementoBot.style.borderRadius = "10px";
                    elementoBot.style.color = "#fff";
                    elementoBot.style.size = "20px";
                    elementoBot.style.background = "#1adda4";


                    const elemTextBot = document.createTextNode(know[result]);
                    var espCommand = (know[result]);

                    elementoBot.appendChild(elemTextBot);


                    console.log(espCommand + "<----TXT");

                    if (espCommand == "Ligando") {
                        var data = "ligar";
                        $.ajax({
                            type: "POST",
                            url: "salvar.php",
                            data: {
                                data
                            },
                            success: function(data) {

                            }
                        })

                    } else if (espCommand == "Desligando") {
                        var data = "desligar";
                        $.ajax({
                            type: "POST",
                            url: "salvar.php",
                            data: {
                                data
                            },
                            success: function(data) {

                            }
                        })
                    }


                    document.getElementById("chatlogi").appendChild(imgbot);
                    document.getElementById("chatlogi").appendChild(elementoBot);
                    document.getElementById("chatlogi").appendChild(espaco);





                } else {
                    //USER
                    var esp = document.createElement('br');
                    var user = result;
                    var imguser = document.createElement('img');
                    imguser.src = 'assets/img/user.png';

                    const element = document.createElement('div');
                    element.classList.add('chat', 'me');

                    imguser.style.width = "60px";
                    imguser.style.height = "60px";
                    imguser.style.background = "#ccc";
                    imguser.style.borderRadius = "50%";
                    imguser.style.overflow = 'hidden';
                    imguser.style.float = 'right';


                    element.setAttribute("src", "assets/img/user.png");
                    element.setAttribute("width", "304");
                    element.setAttribute("height", "228");
                    element.setAttribute("alt", "The Pulpit Rock");

                    element.style.width = "80%";
                    element.style.padding = "15px";
                    element.style.margin = "5px 10px 0";
                    element.style.borderRadius = "10px";
                    element.style.color = "#fff";
                    element.style.size = "20px";
                    element.style.background = "#1ddced";




                    const elemText = document.createTextNode(user);

                    element.appendChild(elemText);

                    document.getElementById("chatlogi").appendChild(imguser);
                    document.getElementById("chatlogi").appendChild(element);
                    document.getElementById("chatlogi").appendChild(esp);
                    console.log(element);

                    const elemento = document.createElement('div');
                    elemento.classList.add('chat', 'bot');
                    console.log(elemento);

                    //ELIRIA
                    var espaco = document.createElement('br');
                    var imgbot = document.createElement('img');
                    imgbot.src = 'assets/img/bot.png';

                    const elementoBot = document.createElement('div');
                    elementoBot.classList.add('chat', 'bot');

                    imgbot.style.width = "60px";
                    imgbot.style.height = "60px";
                    imgbot.style.background = "#ccc";
                    imgbot.style.borderRadius = "50%";
                    imgbot.style.overflow = 'hidden';
                    imgbot.style.float = 'left';
                    imgbot.style.margin = "10px";

                    elementoBot.style.width = "80%";
                    elementoBot.style.padding = "15px";
                    elementoBot.style.margin = "5px 15px 0";
                    elementoBot.style.borderRadius = "10px";
                    elementoBot.style.color = "#fff";
                    elementoBot.style.size = "20px";
                    elementoBot.style.background = "#1adda4";


                    const elemTextBot = document.createTextNode("Não Entendi :(");

                    elementoBot.appendChild(elemTextBot);


                    document.getElementById("chatlogi").appendChild(imgbot);
                    document.getElementById("chatlogi").appendChild(elementoBot);
                    document.getElementById("chatlogi").appendChild(espaco);
                }

            }, false);
        } else {
            alert('Este navegador não suporta a funcionalidade de comando de voz ainda!');
        }

    }, false);
</script>


</html>
