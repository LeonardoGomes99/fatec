# Eliria_Housecarl
Projeto_TG IOT

[OUTDATED 19/06/2020]

Requirements:
-NGROK

--INSIDE OF NGROK.yml FILE:

---authtoken: key(get on site)
---tunnels:
----first-app:
------addr: 80
------proto: http
----second-app:
------addr: 81
------proto: http

-ESP8266

-Google Chrome (to Speech Recognition API work properly)
          
[UPDATED 24/06/2020]

Enter Link: https://eliria-housecarl.herokuapp.com

Eliria Web Server Password: "admin"

