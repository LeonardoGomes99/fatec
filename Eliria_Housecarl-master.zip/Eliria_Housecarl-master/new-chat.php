<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
/* Caixas de Mensagens */
body {
  margin: 0 auto;
  max-width: 800px;
  padding: 0 20px;
}
/* Caixa Principal */
.ContainerMessageBox{
  border: 2px solid #dedede;
  background-color: #FF5733;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}
/* Caixa onde vão as Mensagens */
.myContainer{
  height: 800px;
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
  overflow: auto;
}
/* Mensagens */
.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}
.darker {
  border-color: #ccc;
  background-color: #ddd;
}
.container::after {
  content: "";
  clear: both;
  display: table;
}
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}
.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}
.time-right {
  float: right;
  color: #aaa;
}
.time-left {
  float: left;
  color: #999;
}

/* Inputs */
.InputMessage {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  height: 50px;
  width: 50%;
}
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
  cursor: pointer;
  font-size: 8px;
}
</style>
</head>
<body>

<div class="ContainerMessageBox">

    <div id="myContainer" class="myContainer">

    </div>

    <div class="w3-half">

      <input maxlength="23" id="UserMessage" class="InputMessage"></textarea>

      <button onmousedown="bleep.play()" class="button" id="SendMessage">
        <img src="assets/img/send.png" width="30" height="25" alt="submit" />
      </button>

      <button onmousedown="bleep.play()" class="button" id="speakBtn">
          <img src="assets/img/mic.png" width="30" height="25" alt="submit" />
      </button>

      <button onclick="v1()">A</button>
      <button onclick="v2()">B</button>



    </div>
<div>



</body>
<script>
var bleep = new Audio();
bleep.src = "assets/sfx/conf.wav";
var distanceBetween;
var myInterval;
var dNow = new Date();
var hora = dNow.getHours() + ':' + dNow.getMinutes();
know = {
    "Oi": "Olá",
    "Como vai": "muito bem :)",
    "Ligar": "ligando",
    "Desligar": "desligando",
    "Ok": ":D"
};

/*** CRIAR MENSAGEM ***/
function UserMessageSend(message){
  $('#myContainer').append('<div class="container darker"><img src="assets/img/user.png" alt="Avatar" class="right" style="width:100%;"><p>'+message+'</p><span class="time-left">'+hora+'</span></div>');
}
function BotMessageSend(message){
  $('#myContainer').append('<div class="container"><img src="assets/img/bot.png" alt="Avatar" style="width:100%;"><p>'+message+'</p><span class="time-right">'+hora+'</span></div>');
}

/*** ENVIAR MENSAGEM ***/
$("#SendMessage").click(function(){
    var user = $('#UserMessage').val();
    $('#UserMessage').val("");
    UserMessageSend(user);
    if (user in know) {
    BotMessageSend(know[user]);
      /* AJAX ENVIANDO DADOS PRO ESP */
      if (know[user] == "Ligando") {
          var data = "ligar";
          $.ajax({
              type: "POST",
              url: "salvar.php",
              data: {
                  data
              },
              success: function(data) {
              }
          })
      }else if (know[user] == "Desligando") {
          var data = "desligar";
          $.ajax({
              type: "POST",
              url: "salvar.php",
              data: {
                  data
              },
              success: function(data) {
              }
          })
      }
    /* AJAX ENVIANDO DADOS PRO ESP */
    } else {
      BotMessageSend("Não Entendi!");
    }
});


/*** ENVIAR COMANDO DE VOZ ***/
window.addEventListener('DOMContentLoaded', function() {
    var speakBtn = document.querySelector('#speakBtn');

    // testa se o navegador suporta o reconhecimento de voz
    if (window.SpeechRecognition || window.webkitSpeechRecognition) {

        // captura a voz
        var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;

        var recognition = new SpeechRecognition();

        // inicia reconhecimento
        speakBtn.addEventListener('click', function(e) {
            recognition.start();
        }, false);

        // resultado do reconhecimento
        recognition.addEventListener('result', function(e) {
            console.log(e);
            var convex = e.results[0][0].transcript;
            var result = convex.charAt(0).toUpperCase() + convex.slice(1);
            UserMessageSend(result);
            if (result in know) {
              BotMessageSend(know[result]);
              if (know[result] == "Ligando") {
                  var data = "ligar";
                  $.ajax({
                      type: "POST",
                      url: "salvar.php",
                      data: {
                          data
                      },
                      success: function(data) {

                      }
                  })
              } else if (know[result] == "Desligando") {
                  var data = "desligar";
                  $.ajax({
                      type: "POST",
                      url: "salvar.php",
                      data: {
                          data
                      },
                      success: function(data) {

                      }
                  })
              }

            } else {
              BotMessageSend("Não Entendi!");
            }
        }, false);
    } else {
        alert('Este navegador não suporta a funcionalidade de comando de voz ainda!');
    }
}, false);


/*** DISTANCIA ENTRE O ESP ***/

  function v1(){
  myInterval = setInterval(function()
  {
    getLocation();
  }, 1000);
  }


  function v2(){
  clearInterval(myInterval);
  }


function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    alert("Este navegador não suporta a funcionalidade de localização ainda!");
  }
}

function showPosition(position) {
    //getDistanceFromLatLonInKm(-22.557162, -44.961131,position.coords.latitude,position.coords.longitude);
    //getDistanceFromLatLonInKm(position.coords.latitude,position.coords.longitude,position.coords.latitude,position.coords.longitude);
    getDistanceFromLatLonInKm(-22.586352,-44.962671,position.coords.latitude,position.coords.longitude);
}

function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2-lat1);  // deg2rad below
  var dLon = deg2rad(lon2-lon1);
  var a =
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ;
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  var d = R * c; // Distance in km
  console.log(d);
  distanceBetween = d.toFixed(3);
  //BotMessageSend("Distancia entre os 2 objetos: "+distanceBetween);

  if (distanceBetween <= 0.063) {
      var data = "ligar";
      $.ajax({
          type: "POST",
          url: "salvar.php",
          data: {
              data
          },
          success: function(data) {

          }
      })
  }else{
    var data = "desligar";
    $.ajax({
        type: "POST",
        url: "salvar.php",
        data: {
            data
        },
        success: function(data) {

        }
    })
  }


}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}



</script>
</html>
