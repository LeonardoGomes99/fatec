<?php

$arquivo = fopen('save.txt', 'r');


    $linha = fgets($arquivo);
    echo $linha;

fclose($arquivo);
