<!DOCTYPE html>
<html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>

<p>Click the button to get your coordinates.</p>

<button onclick="getLocation()">Try It</button>


<p id="demo"></p>

<script>
var distanceBetween;

var x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;

    //getDistanceFromLatLonInKm(-22.557162, -44.961131,position.coords.latitude,position.coords.longitude);
    //getDistanceFromLatLonInKm(position.coords.latitude,position.coords.longitude,position.coords.latitude,position.coords.longitude);
    getDistanceFromLatLonInKm(-22.586352,-44.962671,position.coords.latitude,position.coords.longitude);
}

function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
  var R = 6371; // Radius of the earth in km
  var dLat = deg2rad(lat2-lat1);  // deg2rad below
  var dLon = deg2rad(lon2-lon1);
  var a =
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ;
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  var d = R * c; // Distance in km
  console.log(d);
  distanceBetween = d.toFixed(3);
  x.innerHTML = "Distancia entre os 2 objetos: "+distanceBetween;


  if (distanceBetween <= 0.063) {
      var data = "ligar";
      $.ajax({
          type: "POST",
          url: "salvar.php",
          data: {
              data
          },
          success: function(data) {

          }
      })
  }else{
    var data = "desligar";
    $.ajax({
        type: "POST",
        url: "salvar.php",
        data: {
            data
        },
        success: function(data) {

        }
    })
  }


}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}
</script>

</body>
</html>
