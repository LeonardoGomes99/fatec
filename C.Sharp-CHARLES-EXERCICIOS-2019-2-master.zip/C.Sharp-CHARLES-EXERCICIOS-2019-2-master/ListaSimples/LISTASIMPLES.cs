﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        
        static void Main(string[] args)
        {

            contador();
            

        }



        static void contador()
        {

            List<Int32> listaA = new List<Int32>();


            int x=0,a;
                                  
            while (x < 10)
            {
                Console.WriteLine("Entre com o Valor: ");
                a = int.Parse(Console.ReadLine());
                listaA.Add(a);
                a = 0;
                x = x + 1;
                Console.WriteLine("|-----------------------------------|");
                Console.WriteLine("|---------------[LISTA]-------------|");
                Console.WriteLine("|-----------------------------------|");
                Console.WriteLine("\n");
                listaA.ForEach(Console.WriteLine);
                Console.WriteLine("\n");
                Console.WriteLine("------------------------------------------");


            }
            Console.WriteLine("-------------[DEAD-------END]-------------");
            Console.ReadKey();

        }


    }
}
